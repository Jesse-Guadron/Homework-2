'''
Jesse A. Guadron
guadron_jesse_alexan@student.smc.edu
CS87A, Fall 2023
Homework 2
'''

# Scrambled alphabet
scrambled_alphabet = "EHTGDBWIUQRXLMVFSJCPYZKAON"

def encrypt_message(message):
    """
    Encrypt a given message using the scrambled alphabet.

    Args:
        message (str): The message to encrypt.

    Returns:
        str: The encrypted message.
    """
    encrypted_message = ""
    for char in message:
        if char.isalpha():
            if char.isupper():
                position = ord(char) - ord('A')
                encrypted_char = scrambled_alphabet[position]
                encrypted_message += encrypted_char
            elif char.islower():
                position = ord(char) - ord('a')
                encrypted_char = scrambled_alphabet[position].lower()
                encrypted_message += encrypted_char
        else:
            encrypted_message += char  # Keep non-letter characters as they are
    return encrypted_message

def decrypt_message(encrypted_message):
    """
    Decrypt a given message using the scrambled alphabet.

    Args:
        encrypted_message (str): The encrypted message to decrypt.

    Returns:
        str: The decrypted message.
    """
    decrypted_message = ""
    for char in encrypted_message:
        if char.isalpha():
            if char.isupper():
                position = scrambled_alphabet.index(char)
                decrypted_char = chr(position + ord('A'))
                decrypted_message += decrypted_char
            elif char.islower():
                position = scrambled_alphabet.index(char.upper())
                decrypted_char = chr(position + ord('a'))
                decrypted_message += decrypted_char
        else:
            decrypted_message += char
    return decrypted_message

while True:
    print("Select an option:")
    print("1. Encrypt a message")
    print("2. Decrypt a message")
    print("3. Quit")

    option = input("> ")

    if option == "1":
        message_to_encrypt = input("Enter a message to encrypt: ")
        encrypted_message = encrypt_message(message_to_encrypt)
        print("The secret message is:", encrypted_message)
    elif option == "2":
        message_to_decrypt = input("Enter a message to decrypt: ")
        decrypted_message = decrypt_message(message_to_decrypt)
        print("The secret message is:", decrypted_message)
    elif option == "3":
        print("Goodbye!")
        break
    else:
        print("Invalid option. Please select 1, 2, or 3.")